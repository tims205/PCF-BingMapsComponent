var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./BingMapsComponent/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./BingMapsComponent/index.ts":
/*!************************************!*\
  !*** ./BingMapsComponent/index.ts ***!
  \************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval(" /// <reference path=\"../node_modules/bingmaps/types/MicrosoftMaps/Microsoft.Maps.d.ts\" />\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.BingMapsComponent = void 0;\n\nvar BingMapsComponent =\n/** @class */\nfunction () {\n  /**\r\n   * Empty constructor.\r\n   */\n  function BingMapsComponent() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  BingMapsComponent.prototype.init = function (context, notifyOutputChanged, state, container) {\n    //this will ensure that if the container size changes the updateView function will be called.\n    context.mode.trackContainerResize(true); // Add control initialization code\n\n    this._notifyOutputChanged = notifyOutputChanged;\n    this._context = context;\n    this._container = container;\n    this._bMapIsLoaded = false;\n    this.addBingMapsScriptToHeader(this._context);\n    var mainDiv = document.createElement(\"div\");\n    mainDiv.setAttribute(\"id\", \"mainDiv\");\n    this._mapDiv = document.createElement(\"div\");\n\n    this._mapDiv.setAttribute(\"id\", \"mapDiv\");\n\n    this._mapDiv.style.height = this._context.mode.allocatedHeight !== -1 ? (this._context.mode.allocatedHeight - 25).toString() + \"px\" : \"calc(100% - 25px)\";\n    this._mapInfoDiv = document.createElement(\"div\");\n\n    this._mapInfoDiv.setAttribute(\"id\", \"mapInfoDiv\");\n\n    mainDiv.appendChild(this._mapDiv);\n    mainDiv.appendChild(this._mapInfoDiv);\n\n    this._container.appendChild(mainDiv); // Set a paging size\n\n\n    context.parameters.ViewDataSet.paging.setPageSize(1000);\n    this.initMap();\n  };\n\n  BingMapsComponent.prototype.initMap = function () {\n    var _this = this;\n\n    var self = this;\n\n    if (!this._bMapScriptIsLoaded) {\n      setTimeout(function () {\n        self.initMap();\n      }, 1000);\n      return;\n    }\n\n    this._bMapOptions = {\n      zoom: 0,\n      center: new Microsoft.Maps.Location(0, 0),\n      mapTypeId: Microsoft.Maps.MapTypeId.road\n    };\n    this._bMap = new Microsoft.Maps.Map(this._mapDiv, this._bMapOptions);\n    this._bMapInfoBox = new Microsoft.Maps.Infobox(this._bMap.getCenter(), {\n      visible: false\n    });\n\n    this._bMapInfoBox.setMap(this._bMap);\n\n    this._bMapLoadingBox = new Microsoft.Maps.Infobox(this._bMap.getCenter(), {\n      htmlContent: '<div class=\"loadingInfoBox\"><div class=\"loadingText\">Loading</div>',\n      visible: true\n    });\n\n    this._bMapLoadingBox.setMap(this._bMap); // Close the info box when clicking anywhere on the map\n\n\n    Microsoft.Maps.Events.addHandler(this._bMap, 'click', function () {\n      _this._bMapInfoBox.setOptions({\n        visible: false\n      });\n    });\n    this._bMapIsLoaded = true;\n  };\n\n  BingMapsComponent.prototype.addBingMapsScriptToHeader = function (context) {\n    var _this = this;\n\n    var apiKey = context.parameters.bingMapsAPIKey.raw || \"\"; //var apiKey = \"AqYzGoLfTyr9d51Bbl5tCexU6UHg4J88320qccuYCFSSLVvuIvs_sr1MuN1OX4Ys\";\n\n    var headerScript = document.createElement(\"script\");\n    headerScript.type = 'text/javascript';\n    headerScript.id = \"BingMapsHeaderScript\";\n    headerScript.async = true;\n    headerScript.defer = true;\n    headerScript.src = \"https://www.bing.com/api/maps/mapcontrol?key=\" + apiKey;\n\n    headerScript.onload = function () {\n      _this._bMapScriptIsLoaded = true;\n    };\n\n    this._container.appendChild(headerScript);\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  BingMapsComponent.prototype.updateView = function (context) {\n    // Add code to update control view\n    var self = this;\n    var dataSet = context.parameters.ViewDataSet; //if we are in a canvas app we need to resize the map to make sure it fits inside the allocatedHeight\n\n    if (this._context.mode.allocatedHeight !== -1) {\n      this._mapDiv.style.height = (this._context.mode.allocatedHeight - 25).toString() + \"px\";\n    } //if data set has additional pages retrieve them before running anything else\n\n\n    if (dataSet.paging.hasNextPage) {\n      dataSet.paging.loadNextPage();\n      return;\n    }\n\n    this.populateMap();\n  };\n\n  BingMapsComponent.prototype.populateMap = function () {\n    var self = this;\n\n    if (!this._bMapIsLoaded) {\n      setTimeout(function () {\n        self.populateMap();\n      }, 1000);\n      return;\n    }\n\n    this._bMapLoadingBox.setOptions({\n      visible: false\n    });\n\n    var dataSet = this._context.parameters.ViewDataSet;\n    var params = this._context.parameters; // Get the field names that hold the values we use\n\n    var keys = {\n      lat: params.latFieldName.raw ? this.getFieldName(dataSet, params.latFieldName.raw) : \"\",\n      long: params.longFieldName.raw ? this.getFieldName(dataSet, params.longFieldName.raw) : \"\",\n      name: params.primaryFieldName.raw ? this.getFieldName(dataSet, params.primaryFieldName.raw) : \"\",\n      description: params.descriptionFieldName.raw ? this.getFieldName(dataSet, params.descriptionFieldName.raw) : \"\",\n      locationTime: params.locationTimestamp.raw ? this.getFieldName(dataSet, params.locationTimestamp.raw) : \"\"\n    }; //if dataset is empty or the lat/long fields are not defined then end\n\n    if (!dataSet || !keys.lat || !keys.long) {\n      return;\n    }\n\n    this._bMap.entities.clear();\n\n    var totalRecordCount = dataSet.sortedRecordIds.length; // locationResults is later used to generate the map bounding box \n\n    var locationResults = []; // Limit the number of pins that will be shown\n\n    var recordLimit = this._context.parameters.maxLocationsToShow.raw || 0;\n\n    if (totalRecordCount > recordLimit) {\n      totalRecordCount = recordLimit;\n    } // Add each record to the map\n\n\n    for (var i = 0; i < totalRecordCount; i++) {\n      var recordId = dataSet.sortedRecordIds[i];\n      var record = dataSet.records[recordId];\n      var lat = record.getValue(keys.lat);\n      var long = record.getValue(keys.long);\n      var name = record.getValue(keys.name);\n      var description = record.getValue(keys.description);\n      var hasExpired = false;\n      var locationRecordedDateTime = \"\"; // Determine if the time the location was recorded has now expired\n\n      if (keys.locationTime != \"\" && params.locationExpiryTime.raw && params.locationExpiryTime.raw > 0) {\n        var locationRecordedOn = new Date(record.getValue(keys.locationTime)).getTime();\n        var minutesExpiry = params.locationExpiryTime.raw ? params.locationExpiryTime.raw : 0;\n        var dateTimeNow = new Date().getTime();\n        var expiresOn = dateTimeNow - minutesExpiry * 60000;\n\n        if (locationRecordedOn < expiresOn) {\n          hasExpired = true;\n        }\n\n        locationRecordedDateTime = record.getFormattedValue(keys.locationTime);\n      }\n\n      var pushpinLatLong = new Microsoft.Maps.Location(lat, long);\n      locationResults.push(pushpinLatLong);\n      var pushPin = new Microsoft.Maps.Pushpin(pushpinLatLong, {\n        title: name.toString()\n      }); // Set metadata that is used for mouseover and click events\n\n      pushPin.metadata = {\n        title: name,\n        description: keys.description && record.getValue(keys.description) ? record.getValue(keys.description) : \"\",\n        entityId: recordId,\n        entityName: dataSet.getTargetEntityType(),\n        locationLoggedOn: locationRecordedDateTime,\n        locationHasExpired: hasExpired === true ? \"(Expired)\" : \"\"\n      };\n\n      if (hasExpired === true) {\n        pushPin.setOptions({\n          color: \"gray\"\n        });\n      } else {\n        pushPin.setOptions({\n          color: \"orange\"\n        });\n      }\n\n      Microsoft.Maps.Events.addHandler(pushPin, 'click', this.pushPinInfoBoxOpen.bind(this));\n\n      this._bMap.entities.push(pushPin);\n    } //generate the bounding box for the map to allow user to quickly see the area in which the pins are located.\n\n\n    this.generateBoundingBox(locationResults);\n  };\n\n  BingMapsComponent.prototype.pushPinInfoBoxOpen = function (e) {\n    if (this._bMapInfoBox.getVisible() === true) {\n      this._bMapInfoBox.setOptions({\n        visible: false\n      });\n\n      return;\n    }\n\n    if (e.target.metadata) {\n      //Define an HTML template for a custom infobox.\n      var infoboxTemplate = \"<div class=\\\"customInfobox\\\"><div class=\\\"title\\\">\" + e.target.metadata.title + \"</div>\" + e.target.metadata.description + \" <br />Last Seen: \" + e.target.metadata.locationLoggedOn + \" \" + e.target.metadata.locationHasExpired + \"</div>\";\n      var self = this; //Set the infobox options with the metadata of the pushpin.\n      //this._bMapInfoBox.setOptions({\n      //location: e.target.getLocation(),\n      //htmlContent: infoboxTemplate.replace('{title}', e.target.metadata.title).replace('{description}', e.target.metadata.description)\n      //title: e.target.metadata.title,\n      //description: e.target.metadata.description,\n      //visible: true,\n      //actions: [{\n      //\tlabel: 'Open Record',\n      //\teventHandler: function(){\n      //\t\t//self._context.navigation.openForm({openInNewWindow: true, entityId: e.target.metadata.entityId, entityName: e.target.metadata.entityName })\n      //\t}\n      //}]\n      //});\n\n      this._bMapInfoBox.setLocation(e.target.getLocation()); //this._bMapInfoBox.setHtmlContent('<div class=\"customInfobox\"><div class=\"title\">HELLO</div></div>');\n      //this._bMapInfoBox.setHtmlContent(infoboxTemplate.replace('{title}', e.target.metadata.title).replace('{description}', e.target.metadata.description));\n\n\n      this._bMapInfoBox.setHtmlContent(infoboxTemplate);\n\n      this._bMapInfoBox.setOptions({\n        visible: true\n      });\n    }\n  };\n\n  BingMapsComponent.prototype.generateBoundingBox = function (locationResults) {\n    if (locationResults.length > 0) {\n      locationResults.sort(this.compareLocationValues('latitude'));\n      var minLat = locationResults[0].latitude;\n      var maxLat = locationResults[locationResults.length - 1].latitude;\n      locationResults.sort(this.compareLocationValues('longitude'));\n      var minLong = locationResults[0].longitude;\n      var maxLong = locationResults[locationResults.length - 1].longitude;\n      var box = Microsoft.Maps.LocationRect.fromEdges(maxLat, minLong, minLat, maxLong);\n\n      this._bMap.setView({\n        bounds: box\n      });\n    }\n  };\n\n  BingMapsComponent.prototype.compareLocationValues = function (key, order) {\n    if (order === void 0) {\n      order = 'asc';\n    }\n\n    return function innerSort(a, b) {\n      if (!a.hasOwnProperty(key) || !b.hasOwnProperty(key)) {\n        return 0;\n      }\n\n      var loc = key === 'latitude' ? {\n        a: a.latitude,\n        b: b.latitude\n      } : {\n        a: a.longitude,\n        b: b.longitude\n      };\n      var comparison = 0;\n\n      if (loc.a > loc.b) {\n        comparison = 1;\n      } else if (loc.a < loc.b) {\n        comparison = -1;\n      }\n\n      return order === 'desc' ? comparison * -1 : comparison;\n    };\n  };\n  /**\r\n   * If a related field is being utilized this will ensure that the correct alias is being used.\r\n   * @param dataSet\r\n   * @param fieldName\r\n   */\n\n\n  BingMapsComponent.prototype.getFieldName = function (dataSet, fieldName) {\n    var _a; //if the field name does not contain a . then just return the field name\n\n\n    if (fieldName.indexOf('.') == -1) return fieldName; //otherwise we need to determine the alias of the linked entity\n\n    var linkedFieldParts = fieldName.split('.');\n    linkedFieldParts[0] = ((_a = dataSet.linking.getLinkedEntities().find(function (e) {\n      return e.name === linkedFieldParts[0].toLowerCase();\n    })) === null || _a === void 0 ? void 0 : _a.alias) || \"\";\n    return linkedFieldParts.join('.');\n  };\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  BingMapsComponent.prototype.getOutputs = function () {\n    return {};\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  BingMapsComponent.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  return BingMapsComponent;\n}();\n\nexports.BingMapsComponent = BingMapsComponent;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./BingMapsComponent/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('Tim.BingMapsComponent', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.BingMapsComponent);
} else {
	var Tim = Tim || {};
	Tim.BingMapsComponent = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.BingMapsComponent;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}